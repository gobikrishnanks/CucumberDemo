package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class GoogleSearch {
	
	WebDriver driver;
	
	@Given("user navigates to Google Site")
	public void user_navigates_to_google_site() throws InterruptedException {
		System.out.println("navigate_to_Google_Search_Application");
		System.setProperty("webdriver.chrome.driver",
				"C:\\\\eclipseWorkspace\\\\Driver\\\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		Thread.sleep(2000);
		// Navigating to URL
		driver.get("https://www.google.com/");
		Thread.sleep(2000);
	}

	@When("user sees search textbox")
	public void user_sees_search_textbox() throws InterruptedException {
		WebElement inputSearchBox = driver.findElement(By.name("q"));
		Thread.sleep(2000);
		System.out.println("Input Box Enabled=" + inputSearchBox.isEnabled());
		System.out.println("Input Box Displayed=" + inputSearchBox.isDisplayed());
	}

	@Then("user enters {string} in search textbox")
	public void user_enters_in_search_textbox(String searchValue) throws InterruptedException {
		WebElement inputSearchBox = driver.findElement(By.name("q"));
	    inputSearchBox.sendKeys(searchValue);
	    Thread.sleep(2000);
	    driver.findElement(By.name("btnK")).click(); // click the submit
	}

	@Then("user clicks on {string} Result")
	public void user_clicks_on_first_search_result(String firstSearch) throws InterruptedException {
		driver.findElement(By.xpath("//*[contains(text(),'"+firstSearch+"')]")).click(); // click the first search result
		Thread.sleep(2000);
		String url = driver.getCurrentUrl();
		String title = driver.getTitle();
		System.out.println("URL=" + url);
		System.out.println("TITLE=" + title);
	}

	@Then("user asserts First Search {string}")
	public void user_asserts_first_search(String title) {
		String actualTitle = driver.getTitle();
		Assert.assertEquals(actualTitle, title);
	}

	@Then("user closes the browser")
	public void user_closes_the_browser() {
		try{
			driver.quit();
		}catch(RuntimeException e) {
			e.printStackTrace();
		}
	}

}
